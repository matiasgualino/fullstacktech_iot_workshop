package com.example.mgualino.fstworkshop;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.hardware.Camera;
import android.util.Log;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.mgualino.fstworkshop.model.MyTaggedDeal;

import com.mercadopago.constants.Sites;
import com.mercadopago.core.MercadoPago;
import com.mercadopago.model.ApiException;
import com.mercadopago.model.DecorationPreference;
import com.mercadopago.model.Issuer;
import com.mercadopago.model.PayerCost;
import com.mercadopago.model.PaymentMethod;
import com.mercadopago.model.Token;

import java.math.BigDecimal;
import java.util.List;
import java.util.logging.Handler;

import me.benear.beacons.BenearBeaconsClient;
import me.benear.core.BenearOffline;
import me.benear.model.OnDetectionCallback;
import me.benear.model.utils.FileUtils;
import me.benear.model.utils.JsonUtil;


public class CameraActivity extends Activity implements SurfaceHolder.Callback {

    Camera camera;
    SurfaceView surfaceView;
    SurfaceHolder surfaceHolder;
    ImageView dealIcon;
    ImageView handIcon;

    Activity mActivity;

    private BenearBeaconsClient mBeaconsClient;
    private MyTaggedDeal myTaggedDeal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        mActivity = this;

        surfaceView = (SurfaceView) findViewById(R.id.surfaceView);
        dealIcon = (ImageView) findViewById(R.id.deal_icon);
        handIcon = (ImageView)findViewById(R.id.hand_icon);

        dealIcon.setOnDragListener(new ContainerDragListener());
        handIcon.setOnTouchListener(new ImgTouchListener());

        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);

        List<MyTaggedDeal> taggedDeals = JsonUtil.getInstance().listFromJson(FileUtils.getStringFromAsset(this, "deals_database.json"), MyTaggedDeal.class);

        BenearOffline.DatabaseBuilder databaseBuilder = new BenearOffline.DatabaseBuilder();
        for(MyTaggedDeal currentTaggedDeals : taggedDeals) {
            databaseBuilder.addTaggedResource(currentTaggedDeals.getTagId(), currentTaggedDeals);
        }

        BenearOffline.Database myLocalDatabase = databaseBuilder.build();

        BenearOffline offlineProvider = new BenearOffline.Builder()
                .setContext(this)
                .setPublicKey("PK-12331-321321-231")
                .setDatabase(myLocalDatabase)
                .build();

        mBeaconsClient = new BenearBeaconsClient.Builder()
                .setContext(this)
                .addOnDetectionCallbackForType(MyTaggedDeal.class, new OnDetectionCallback<MyTaggedDeal>() {
                    @Override
                    public void onDetected(List<MyTaggedDeal> deals) {
                        resolveDealsFound(deals);
                    }
                })
                .setForegroundScanPeriod(2000L)
                .setBenearProvider(offlineProvider)
                .build();

        mBeaconsClient.startScanning();
    }

    public void resolveDealsFound(List<MyTaggedDeal> deals) {
        MyTaggedDeal newDeal = deals.get(0);
        Log.d("DALE CHE", "Algo encontré = " + newDeal.getTagId());
        if (myTaggedDeal == null || !newDeal.getTagId().equals(myTaggedDeal.getTagId())) {
            myTaggedDeal = newDeal;
        }
        Resources r = getResources();
        final int resourceId = r.getIdentifier(myTaggedDeal.getIconName(), "mipmap", getPackageName());

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dealIcon.setImageResource(resourceId);
            }
        });

        mBeaconsClient.startScanning();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        if (surfaceHolder.getSurface() == null) {
            return;
        }

        try {
            camera.stopPreview();
        } catch (Exception e) {
        }

        try {

            camera.setDisplayOrientation(90);

            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();
        } catch (Exception e) {

        }
    }

    public void surfaceCreated(SurfaceHolder holder) {
        try {
            camera = Camera.open();
        } catch (RuntimeException e) {
            System.err.println(e);
            return;
        }

        try {
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();
        } catch (Exception e) {
            System.err.println(e);
            return;
        }
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
        if (camera != null) {
            camera.stopPreview();
            camera.release();
            camera = null;
        }

    }

    private class ImgTouchListener implements View.OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                view.startDrag(data, shadowBuilder, view, 0);
                view.setVisibility(View.INVISIBLE);
                return true;
            } else {
                return true;
            }
        }
    }

    private class ContainerDragListener implements View.OnDragListener {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            int action = event.getAction();
            switch (event.getAction()) {
                case DragEvent.ACTION_DROP:
                    if (myTaggedDeal != null) {
                        DecorationPreference decorationPreference = new DecorationPreference();
                        decorationPreference.setBaseColor("#FFCC3E");
                        decorationPreference.enableDarkFont();

                        new MercadoPago.StartActivityBuilder()
                                .setActivity(mActivity)
                                .setPublicKey("TEST-d941de2c-22bd-4e9e-a06c-48a404b66080")
                                .setAmount(new BigDecimal(myTaggedDeal.getPrice()))
                                .setSite(Sites.ARGENTINA)
                                .setInstallmentsEnabled(true)
                                .setDecorationPreference(decorationPreference)
                                .startCardVaultActivity();
                    }
                default:
                    break;
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == MercadoPago.CARD_VAULT_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null) {

                // Obtener os dados inseridos pelo usuario

                PaymentMethod paymentMethod = JsonUtil.getInstance().fromJson(data.getStringExtra("paymentMethod"), PaymentMethod.class);
                Issuer issuer = JsonUtil.getInstance().fromJson(data.getStringExtra("issuer"), Issuer.class);
                Token token = JsonUtil.getInstance().fromJson(data.getStringExtra("token"), Token.class);
                PayerCost payerCost = JsonUtil.getInstance().fromJson(data.getStringExtra("payerCost"), PayerCost.class);

                String message = "PaymentMethod: " + paymentMethod.getId();

                if (issuer != null) {
                    message += " - Issuer: " + issuer.getName();
                }

                if (payerCost != null) {
                    message += " - PayerCost: " + payerCost.getInstallments();
                }

                if (token != null) {
                    message += " - Token: " + token.getId();
                }

                Toast.makeText(getApplicationContext(), message,
                        Toast.LENGTH_LONG).show();
            } else {

                if ((data != null) &&
                        (data.getSerializableExtra("apiException") != null)) {
                    ApiException apiException =
                            (ApiException) data.getSerializableExtra("apiException");

                    Toast.makeText(getApplicationContext(), apiException.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}
