package com.example.mgualino.fstworkshop.model;

/**
 * Created by mgualino on 11/8/16.
 */


import me.benear.model.BeRangedResource;

public class MyTaggedDeal implements BeRangedResource {

    // Atributos de la clase
    private String name;
    private String iconName;
    private Double price;

    // Identificador
    private String tagId;

    private Double distance;

    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getIconName() {
        return iconName;
    }

    public void setIconName(String iconName) {
        this.iconName = iconName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void setDistance(Double distance) {
        this.distance = distance;
    }

    @Override
    public Double getDistance() {
        return distance;
    }
}
